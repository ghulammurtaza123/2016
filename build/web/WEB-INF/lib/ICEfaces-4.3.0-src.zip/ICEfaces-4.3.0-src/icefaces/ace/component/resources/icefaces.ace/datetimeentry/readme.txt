ICE-8363: DateTimeEntry conversion error when submitted.
ICE-8380: ace:dateTimeEntry - buttonPanel "Done" button appears even when not in popup mode.
ICE-9392: REGRESSION:  ace:dateTimeEntry - Clicking Today button closes popup.
ICE-10918: fix for honouring the selected time zone when pressing the Today/Now button
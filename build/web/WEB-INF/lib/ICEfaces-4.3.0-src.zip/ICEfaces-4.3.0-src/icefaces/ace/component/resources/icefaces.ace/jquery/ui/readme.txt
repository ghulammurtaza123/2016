ICE-8154: in-field label handling for calendar.
ICE-8341: showcase - dateTimeEntry with navigator enabled error on Jboss7.
ICE-8453: ace:dateTimeEntry - tab order is lost after selecting a date with the mouse.
ICE-8552: Add click listener on calendar input field to show calendar popup.
ICE-7867: Add touch-screen interface support to ACE components. (Added plugin jquery.ui.touch-punch.js.)
ICE-8631: added line that was missing in 1.8.24 in progress bar widget, where the value and percentage numbers are passed to the event
ICE-8665: ace:dateTimeEntry text input key-events causing slowdown with large DOMs in IE7/8.
ICE-8752: Add ARIA role and attributes to SliderEntry.
ICE-8644: ace:dateTimeEntry - Add a way to change the calendar icon title tooltip.
ICE-8748: added code to bring the modal dialog overlay to the same dom tree level as the dialog itself, so that the overlay doesn't appear on top of the dialog
ICE-8695: Added ARIA role and attributes to Dialog.
ICE-8801: Add ARIA role and attributes to ProgressBar.
ICE-8692: Add ARIA Roles for ace:dateTimeEntry.
ICE-8820: ace:dateTimeEntry - Now and Today button functionality is inconsistent.
ICE-8868: Add ARIA role and attributes to Accordion.
ICE-8869: prevent getting stuck forever with draggable when clicking on a scrollbar in Webkit and IE9 browsers
ICE-9392: REGRESSION:  ace:dateTimeEntry - Clicking Today button closes popup.
ICE-9147: added support for header facet in ace:dialog
ICE-9579: commented out code to programatically set datepicker width
ICE-9001: added support for 'handle' attribute to Dialog widget
ICE-10190: fix to hide the datepicker root/placeholder node when aria-hidden="true"
ICE-10261: added 'activeNoEvent' option to the Accordion widget to allow activating an accordion pane without triggering the 'changestart' event and without focusing on the pane header
ICE-10290: use the relocated jQuery definitions in ice.ace.jq when jQuery global variable is no longer present (after jQuery.noConflict(true) was invoked)
ICE-10470: fix to avoid setting explicit heights of panes when the accordion isn't visible at initialization time, in order to avoid zero-valued heights
ICE-10918: fix for honouring the selected time zone when pressing the Today/Now button
ICE-10970: increased z-index of popup datepicker
ICE-10735: added onclick="this.focus();" to slider handle for accesskey purposes on Chrome
ICE-11292: set overflow CSS property to hidden on the main content pane, since the inner content pane will now contain the overflow:auto; styling
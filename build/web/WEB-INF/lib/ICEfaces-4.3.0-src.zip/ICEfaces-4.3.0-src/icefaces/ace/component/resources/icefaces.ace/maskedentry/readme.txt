Changes to masked entry plugin:
In-field label handling. (ICE-8154)
Add keypress event. (ICE-8812)
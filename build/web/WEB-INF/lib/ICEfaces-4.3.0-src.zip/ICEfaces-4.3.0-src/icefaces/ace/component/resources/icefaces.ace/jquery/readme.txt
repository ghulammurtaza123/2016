- Appended dialog to parent instead of document body
- Added  extensions to jquery-ui.css
ICE-9777 updated to jQuery 1.11.0 and included the jQuery Migrate 1.2.1 plugin
ICE-10037 modified clone() method to redraw contents of canvas tags
ICE-10515 commented out JQMIGRATE jQuery.browser deprecated message
ICE-10560 set jQuery.migrateMute to true, in order to mute all JQMIGRATE warning messages
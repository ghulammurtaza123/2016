/*
 * Copyright 2004-2014 ICEsoft Technologies Canada Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS
 * IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

/*
	Masked Input plugin for jQuery
	Copyright (c) 2007-2009 Josh Bush (digitalbush.com)
	Licensed under the MIT license (http://digitalbush.com/projects/masked-input-plugin/#license)
	Version: 1.2.2 (03/09/2009 22:39:06)
*/
(function($) {
	var pasteEventName = ($.browser.msie ? 'paste' : 'input') + ".mask";
	var iPhone = (window.orientation != undefined);

	$.mask = {
		//Predefined character definitions
		definitions: {
			'9': "[0-9]",
			'a': "[A-Za-z]",
			'*': "[A-Za-z0-9]"
		}
	};

	$.fn.extend({
		//Helper Function for Caret positioning
		caret: function(begin, end) {
			if (this.length == 0) return;
			if (typeof begin == 'number') {
				end = (typeof end == 'number') ? end : begin;
				return this.each(function() {
					if (this.setSelectionRange) {
						this.focus();
						this.setSelectionRange(begin, end);
					} else if (this.createTextRange) {
						var range = this.createTextRange();
						range.collapse(true);
						range.moveEnd('character', end);
						range.moveStart('character', begin);
						range.select();
					}
				});
			} else {
				if (this[0].setSelectionRange) {
					begin = this[0].selectionStart;
					end = this[0].selectionEnd;
				} else if (document.selection && document.selection.createRange) {
					var range = document.selection.createRange();
					begin = 0 - range.duplicate().moveStart('character', -100000);
					end = begin + range.text.length;
				}
				return { begin: begin, end: end };
			}
		},
		unmask: function() { return this.trigger("unmask"); },
		mask: function(mask, settings) {
			if (!mask && this.length > 0) {
				var input = $(this[0]);
				var tests = input.data("tests");
				return $.map(input.data("buffer"), function(c, i) {
					return tests[i] ? c : null;
				}).join('');
			}
			settings = $.extend({
				placeholder: "_",
				completed: null
			}, settings);

			var defs = $.mask.definitions;
			var tests = [];
			var partialPosition = mask.length;
			var firstNonMaskPos = null;
			var len = mask.length;

			$.each(mask.split(""), function(i, c) {
				if (c == '?') {
					len--;
					partialPosition = i;
				} else if (defs[c]) {
					tests.push(new RegExp(defs[c]));
					if(firstNonMaskPos==null)
						firstNonMaskPos =  tests.length - 1;
				} else {
					tests.push(null);
				}
			});

			return this.each(function() {
				var input = $(this);
				var buffer = $.map(mask.split(""), function(c, i) { if (c != '?') return defs[c] ? settings.placeholder : c });
				var ignore = false;  			//Variable for ignoring control keys
				var focusText = input.val();

				input.data("buffer", buffer).data("tests", tests);
                input.data("labelIsInField", settings.labelIsInField);

				function seekNext(pos) {
					while (++pos <= len && !tests[pos]) {}
					return pos;
				}

				function shiftL(pos) {
					while (!tests[pos] && --pos >= 0) {};
					for (var i = pos; i < len; i++) {
						if (tests[i]) {
							buffer[i] = settings.placeholder;
							var j = seekNext(i);
							if (j < len && tests[i].test(buffer[j])) {
								buffer[i] = buffer[j];
							} else
								break;
						}
					}
					writeBuffer();
					input.caret(Math.max(firstNonMaskPos, pos));
				}

				function shiftR(pos) {
					for (var i = pos, c = settings.placeholder; i < len; i++) {
						if (tests[i]) {
							var j = seekNext(i);
							var t = buffer[i];
							buffer[i] = c;
							if (j < len && tests[j].test(t))
								c = t;
							else
								break;
						}
					}
				}

				function keydownEvent(e) {
					var pos = $(this).caret();
					var k = e.keyCode;
					ignore = (k < 16 || (k > 16 && k < 32) || (k > 32 && k < 41));

					//delete selection before proceeding
					if ((pos.begin - pos.end) != 0 && (!ignore || k == 8 || k == 46))
						clearBuffer(pos.begin, pos.end);

					//backspace, delete, and escape get special treatment
					if (k == 8 || k == 46 || (iPhone && k == 127)) {//backspace/delete
						shiftL(pos.begin + (k == 46 ? 0 : -1));
						return false;
					} else if (k == 27) {//escape
						input.val(focusText);
						input.caret(0, checkVal());
						return false;
					}
				}

				function keypressEvent(e) {
                    input.removeData("fromCharCode");
					if (ignore) {
						ignore = false;
						//Fixes Mac FF bug on backspace
						return (e.keyCode == 8) ? false : null;
					}
					e = e || window.event;
					var k = e.charCode || e.keyCode || e.which;
					var pos = $(this).caret();

					if (e.ctrlKey || e.altKey || e.metaKey) {//Ignore
						return true;
					} else if ((k >= 32 && k <= 125) || k > 186) {//typeable characters
						var p = seekNext(pos.begin - 1);
						if (p < len) {
							var c = String.fromCharCode(k);
							if (tests[p].test(c)) {
								shiftR(p);
								buffer[p] = c;
                                input.data("fromCharCode", c);
								writeBuffer();
								var next = seekNext(p);
								$(this).caret(next);
								if (settings.completed && next == len)
									settings.completed.call(input);
							}
						}
					}
					return false;
				}

				function clearBuffer(start, end) {
					for (var i = start; i < end && i < len; i++) {
						if (tests[i])
							buffer[i] = settings.placeholder;
					}
				}

				function writeBuffer() {
				    return input.val(buffer.join('')).val();
				}

				function checkVal(allow) {
					//try to place characters where they belong
					var test = input.val();
					var lastMatch = -1;
					for (var i = 0, pos = 0; i < len; i++) {
						if (tests[i]) {
							buffer[i] = settings.placeholder;
							while (pos++ < test.length) {
								var c = test.charAt(pos - 1);
								if (tests[i].test(c)) {
									buffer[i] = c;
									lastMatch = i;
									break;
								}
							}
							if (pos > test.length)
								break;
						} else if (buffer[i] == test[pos] && i!=partialPosition) {
							pos++;
							lastMatch = i;
						}
					}
					if (!allow && lastMatch + 1 <= partialPosition && !input.data("labelIsInField")) {
						input.val("");
						clearBuffer(0, len);
					} else if (allow || lastMatch + 1 >= partialPosition) {
						writeBuffer();
						if (!allow) input.val(input.val().substring(0, lastMatch + 1));
					}
					return (partialPosition ? i : firstNonMaskPos);
				}

				if (!input.attr("readonly"))
					input
					.one("unmask", function() {
						input
							.unbind(".mask")
							.removeData("buffer")
							.removeData("tests");
					})
					.bind("focus.mask", function() {
                        // ICE-8154: in-field label handling
                        if (input.data("labelIsInField")) {
                            input.val("");
                            input.removeClass(settings.inFieldLabelStyleClass);
                            input.data("labelIsInField", false);
                            input.attr({name: input.attr("id")});
                        }
						focusText = input.val();
						var pos = checkVal();
						writeBuffer();
						if (pos == mask.length)
							input.caret(0, pos);
						else
							input.caret(pos);
					})
					.bind("blur.mask", function() {
						checkVal();
						if (input.val() != focusText)
							input.change();
                        // ICE-8154: in-field label handling
                        if ($.trim(input.val()) == "" && settings.inFieldLabel) {
                            input.val(settings.inFieldLabel);
                            input.addClass(settings.inFieldLabelStyleClass);
                            input.data("labelIsInField", true);
                            input.attr({name: input.attr("id") + "_label"});
                        }
					})
					.bind("keydown.mask", keydownEvent)
					.bind("keypress.mask", keypressEvent)
					.bind(pasteEventName, function() {
						setTimeout(function() {
                            input.caret(checkVal(false));
                        }, 0);
					})
                    .bind('keypress.mask', function(e) {
                        //verify value before a submit triggered by 'Enter' key
                        if (e.keyCode == 13) {
                            checkVal();
                        }
                    })
                    .closest('form').bind('submit', function() {
                        if (input.data("labelIsInField")) {
                            input.val("");
                            input.data("labelIsInField", false);
                            input.attr({name: input.attr("id")});
                            setTimeout(function() {
                                input.val(settings.inFieldLabel);
                                input.data("labelIsInField", true);
                            }, 100);
                        }
                    });

				checkVal(); //Perform initial check for existing values
				// ICE-8154: in-field label handling
				if ($.trim(input.val()) == "" && settings.inFieldLabel) {
					input.val(settings.inFieldLabel);
					input.addClass(settings.inFieldLabelStyleClass);
					input.data("labelIsInField", true);
					input.attr({name: input.attr("id") + "_label"});
				}
			});
		}
	});
})(ice.ace.jq);

/*
 *  InputMask Widget
 */
ice.ace.InputMask = function(id, cfg) {
    this.id = id;
    this.cfg = cfg;
    this.jqId = ice.ace.escapeClientId(id);
    this.jq = ice.ace.jq(this.jqId).find('input[name="'+this.id+'_field"]');
	this.jq.attr('id', this.id + '_field');
	this.jq.get(0).submitOnEnter = 'disabled';

    if (this.cfg.mask) {
        this.cfg.mask = "?" + this.cfg.mask.replace(/\?/g, "");
    }
    if (this.cfg.mask) // only add functionality if mask was provided, otherwise degrade to simple text input
	this.jq.mask(this.cfg.mask, this.cfg);

	if (this.cfg.inFieldLabel) {
		if (!this.cfg.labelIsInField) {
		    ice.ace.setResetValue(this.jq.attr('id'), this.jq.val());
        } else {
            this.jq.val(cfg.inFieldLabel);
        }
	} else {
	    ice.ace.setResetValue(this.jq.attr('id'), this.jq.val());
    }

    this.jq.change(function() { ice.setFocus(''); });
    //Client behaviors
	var behaviors = this.cfg.behaviors;
	var self = this;
    if(behaviors) {
		var element = this.jq;
		if (behaviors.blur) {
			element.bind('blur', function() {
				ice.setFocus('');
				setTimeout(function() {
					if (document.getElementById(self.id+'_field') === element.get(0))
						ice.ace.ab.call(element, behaviors.blur);
				}, 300);
			});
		}
		if (behaviors.change) {
			element.bind('change', function() {
			    ice.ace.ab.call(element, behaviors.change);
			});
			element.bind('keypress', function(e,ui) {
			    if (e.keyCode == 13) {
                    ice.ace.ab.call(element, behaviors.change);
                    e.stopPropagation();
			    }
			});
		}
        if (behaviors.keypress) {
            element.keypress(function (e) {
                var $ = ice.ace.jq, character = $(this).data("fromCharCode");
                if (character) {
                    ice.ace.ab($.extend(true, {params: {"char": character}}, behaviors.keypress));
                }
			});
		}
    }
	if (!behaviors || !behaviors.change) {
		this.jq.bind('keydown', function(e) {
			if (e.keyCode == 13) {
				ice.s(e, self.jq.get(0));
				e.stopPropagation();
				return false;
			}
		});
	}

    //Visuals
    if(this.cfg.theme != false) {
        ice.ace.util.bindHoverFocusStyle(this.jq);
    }
};

ice.ace.InputMask.clear = function(id, inFieldLabel, inFieldLabelStyleClass) {
	var input = ice.ace.jq(ice.ace.escapeClientId(id));
	if (!input.hasClass(inFieldLabelStyleClass))
		ice.ace.setResetValue(id, input.val());
	if (inFieldLabel) {
		input.val(inFieldLabel);
		input.addClass(inFieldLabelStyleClass);
		input.data("labelIsInField", true);
		input.attr({name: input.attr("id") + "_label"});
	} else {
		input.val('');
	}
};

ice.ace.InputMask.reset = function(id, inFieldLabel, inFieldLabelStyleClass) {
	var value = ice.ace.resetValues[id];
	if (ice.ace.isSet(value)) {
		var input = ice.ace.jq(ice.ace.escapeClientId(id));
		if (value) {
			if (inFieldLabel) {
				input.removeClass(inFieldLabelStyleClass);
				input.data("labelIsInField", false);
				input.attr({name: input.attr("id")});
			}
			input.val(value);
		} else ice.ace.InputMask.clear(id, inFieldLabel, inFieldLabelStyleClass);
	}
};